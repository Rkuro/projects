Author: eso observatory
Author webpage: http://www.eso.org/ 
Licence: ATTRIBUTION LICENSE 3.0 (http://creativecommons.org/licenses/by/3.0/us/)
Downloaded at Mazwai.com
